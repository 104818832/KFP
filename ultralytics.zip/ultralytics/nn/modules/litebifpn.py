import torch
import torch.nn as nn
import torch.nn.functional as F


class SEBlock(nn.Module):
    def __init__(self, c, r=16):
        super().__init__()
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, c // r, 1),
            nn.ReLU(),
            nn.Conv2d(c // r, c, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return x * self.fc(x)


class LiteBiFPN(nn.Module):
    def __init__(self, c1, c2):  # c1是输入通道列表 [P3, P4, P5], c2是输出通道
        super().__init__()
        # 通道对齐层
        self.cv1 = nn.Conv2d(c1[0], c2, 1)
        self.cv2 = nn.Conv2d(c1[1], c2, 1)
        self.cv3 = nn.Conv2d(c1[2], c2, 1)

        # 深度卷积
        self.conv = nn.ModuleList([
            nn.Conv2d(c2, c2, 3, 1, 1, groups=c2),
            nn.Conv2d(c2, c2, 3, 1, 1, groups=c2)
        ])

        self.se = nn.ModuleList([SEBlock(c2) for _ in range(3)])

    def forward(self, x):
        p3, p4, p5 = x
        # 1. 通道统一
        p3, p4, p5 = self.cv1(p3), self.cv2(p4), self.cv3(p5)

        # 2. 简单的特征融合 (Top-down)
        p5_up = F.interpolate(p5, size=p4.shape[-2:], mode='nearest')
        p4 = p4 + p5_up
        p4_up = F.interpolate(p4, size=p3.shape[-2:], mode='nearest')
        p3 = p3 + p4_up

        # 3. Bottom-up
        p3_down = F.interpolate(p3, size=p4.shape[-2:], mode='nearest')
        p4 = self.conv[0](p4 + p3_down)
        p4_down = F.interpolate(p4, size=p5.shape[-2:], mode='nearest')
        p5 = self.conv[1](p5 + p4_down)

        # ⭐ 关键：返回三个 Tensor，不要带中括号
        return [self.se[0](p3), self.se[1](p4), self.se[2](p5)]