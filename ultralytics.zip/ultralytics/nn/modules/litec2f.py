import torch
import torch.nn as nn

# 深度可分离卷积
class DWConv(nn.Module):
    def __init__(self, c1, c2, k=3):
        super().__init__()
        self.dw = nn.Conv2d(c1, c1, k, 1, k//2, groups=c1, bias=False)
        self.pw = nn.Conv2d(c1, c2, 1, 1, 0, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU()

    def forward(self, x):
        return self.act(self.bn(self.pw(self.dw(x))))


class LiteC2f(nn.Module):
    def __init__(self, c1, c2, n=1, e=0.5):
        super().__init__()
        c_ = int(c2 * e)

        self.cv1 = nn.Conv2d(c1, 2 * c_, 1, 1)
        self.cv2 = nn.Conv2d((2 + n) * c_, c2, 1)

        self.m = nn.ModuleList(
            [DWConv(c_, c_) for _ in range(n)]
        )

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, 1))

        for m in self.m:
            y.append(m(y[-1]))

        return self.cv2(torch.cat(y, 1))